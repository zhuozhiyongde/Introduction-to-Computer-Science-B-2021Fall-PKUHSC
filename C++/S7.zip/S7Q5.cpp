#include <iostream>
#include <algorithm>

using namespace std;
int c[10005]={0};
int timeuse = 0;
int complex = 0;
int flag=0;
int temp;
void tog(int n,int dis){
	if(n==1)cout<<timeuse<<endl;
	else{
		timeuse += c[dis]+c[dis+1];
//		cout<<n<<" "<<c[0]<<" "<<c[1]<<" "<<c[2]<<" "<<timeuse<<endl;
		c[dis] = c[dis]+c[dis+1];
		c[dis+1] = -1;
		sort(c,c+temp);
		tog(n-1,dis+1);
	}
}


int main() {
	int n;
	cin>>n;
	temp=n;
	int i=0;
	while(i<n){
		cin>>c[i];
		i++;
	}
	sort(c,c+n);
//	int b[4]={-1,1,0,3};
//	sort(b,b+3,cmp);
//	for(int i=0;i<4;i++){
//		cout<<b[i]<<endl;
//	}
	tog(n,0);
//	cout<<"1";
}